# ComplexiteM1

Pour compiler le projet faire make.

-> Génération de 5 éxecutable :
	- Algo1
	- Algo2
	- Algo3
	- Algo4
	- EvalTime

Utilisation :

- Pour les Algo 1, 2, 3 et 4 :
	./Algo* [tableau d'éléments]
		
		ex: ./Algo1 1 -2 3 -4 5 
		ex: ./Algo4 100 -50 80 -45  

- Pour EvalTime, juste lancer l'éxécutable.
Le résultat sera dans le fichier result.csv

Attention ! :
	Cet exécutable utilise tout les coeurs de votre ordinateur.
	Opération longue afin de calculer toutes les valeurs. ( > ~1h)